public class Node
{
    public Object data; //data
    public Node next; //reference to the next Node
    
    public Node (Object d) //Constructor
    {
        data = d;
    }
}
